package org.grostarin.springboot.demorest.dto;

public record BookSearch(String title) {

}
