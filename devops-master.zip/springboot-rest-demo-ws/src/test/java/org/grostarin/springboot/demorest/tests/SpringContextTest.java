package org.grostarin.springboot.demorest.tests;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringContextTest {

    @Test
    public void contextLoads() {
    }
}
